def hello(name):
    return f'Hello, {name}, from mygreatmod!'

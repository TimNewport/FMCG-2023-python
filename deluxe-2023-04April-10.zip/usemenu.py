#!/usr/bin/env python3

import menu
user_choice = menu.menu('a', 'b', 'c')
print(f'User chose {user_choice}')

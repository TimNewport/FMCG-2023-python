if __name__ == '__main__':
    print(f'Hello from {__name__}!')

x = 100

y = [10, 20, 30]

def hello(name):
    return f'Hello, {name}!'

if __name__ == '__main__':
    print(f'Goodbye from {__name__}!')
